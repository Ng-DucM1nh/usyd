cd ~/tests
mkdir test_$1
cd test_$1
touch in
touch out
touch expected
