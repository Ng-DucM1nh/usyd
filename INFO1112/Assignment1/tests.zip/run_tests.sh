cd ~
for path in tests/*
do
    if [[ ! -d $path || "$path" = "oktests" ]]; then
        continue
    fi
    echo -n $path:" "
    python ~/mysh.py < $path/in &> $path/out
    echo $? >> $path/out
    dif=`diff $path/out $path/expected`
    if [ "$dif" = "" ]; then
        echo passed
    else
        echo failed
    fi
done
